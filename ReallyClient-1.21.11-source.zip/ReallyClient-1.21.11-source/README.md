# ReallyClient — Fabric 1.21.11

Client-side modular Minecraft mod aimed at a ReallyWorld-style play setup. Java 21, Fabric Loader 0.18.4, Fabric API 0.141.6+1.21.11, Yarn 1.21.11+build.4.

## Controls

- **Right Shift** — ReallyClient module menu.
- **C (hold)** — Zoom.
- **M** — full-screen loaded-player map.
- **Esc** — close screens.

All keybinds can also be changed in Minecraft Controls.

## Included modules

### HUD / interface
- FPS / coordinates / ping HUD
- Keystrokes
- CPS
- Custom crosshair
- Cooldown panel for vanilla item cooldowns
- 2D player radar
- Same-chunk player list with exact distance and look direction
- Full-screen player map
- custom ReallyClient main menu
- profiles: `default`, `pvp`, `visual`, `performance`

### Visuals / cosmetics
- FullBright
- client-side player/mob/item Glow ESP
- Visible Block ESP: only exposed diamond/emerald/gold/ancient-debris blocks; it does **not** scan hidden blocks as X-Ray
- fixed client-side time
- clear client-side weather
- custom sky color (adjust hue in Settings, exact ARGB can also be edited in the JSON profile)
- modified first-person ViewModel / hand position
- radius particle preview
- jump circle
- pulse particles
- ReallyClient local cape texture
- Chinese-hat particle cosmetic

### PvP helpers
- smooth Aim Assist while the attack key is held; configurable range/FOV/smoothing; no automatic attack
- Aim FOV circle
- Crystal Optimizer that removes the **client-side** item-use cooldown only
- armor durability pinger

### ReallyWorld/server utilities
- Chat Guard: prevents sending messages containing words configured in `bannedWords`
- nickname mention sound/notification
- Anti Rod AFK: while movement keys are idle, suppresses horizontal pull when a fishing bobber is very close
- Hide AFK Bots by configurable nickname fragments
- Near Scanner with sound/chat alerts
- same-chunk Near information
- Auto Command on a timer
- AutoSell command on a timer

### Utility
- FPS Boost mode reduces ReallyClient's own particle/scanner cadence. It is **not** a replacement for Sodium or other renderer optimization mods.
- Discord RPC using local Discord IPC. Set `discordApplicationId` in the active profile JSON.

## Config

After first start, profiles are generated in:

`config/reallyclient/profile_default.json`

The server-specific parts are intentionally configurable because commands, AFK-bot names, prohibited words and ability radiuses can differ between server modes.

Important fields:

```json
{
  "bannedWords": ["example"],
  "afkBotNameFragments": ["afk-bot"],
  "autoCommands": ["/fix all", "/heal"],
  "autoCommandIntervalSeconds": 45,
  "autoSellCommand": "/sell",
  "autoSellIntervalSeconds": 60,
  "discordApplicationId": 0,
  "skyColor": -14783489
}
```

Java JSON stores `int` colors as signed decimal numbers. You can use the in-game Sky setting instead of editing this value manually.

## Build

Requirements: JDK 21 and Gradle 9.x.

```bash
gradle build
```

The built mod is placed in `build/libs/`.

If you only have a phone, the project includes `.github/workflows/build.yml`: upload the source to a GitHub repository, open **Actions → build → Run workflow**, then download the build artifact.

## What is deliberately not claimed

- A client mod cannot make server cooldowns, anti-cheat checks or server tick delays disappear. Crystal Optimizer only changes the local use-delay path.
- The included player map plots players already known/loaded by the client. It does not reveal unloaded or server-hidden players.
- Visible Block ESP only highlights exposed blocks. It is not X-Ray.
- Aim Assist, ESP, automation and similar features may be restricted by a server's rules. Being client-side does not make them undetectable or permitted. Check the current rules for the mode you play.
- `Autosell` is command-based in this starter: NPC GUI automation varies by server/menu and needs a mode-specific adapter if the server does not provide a sell command.

## Project status

This archive is source code, not a precompiled jar. The code is structured as a usable first version rather than a one-file example. Server-specific values are intentionally left in JSON so they can be changed without recompiling.
