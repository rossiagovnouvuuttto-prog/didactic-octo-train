package me.reallyclient.client.gui;

import me.reallyclient.client.config.ConfigManager;
import me.reallyclient.client.core.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

public final class ReallyMainMenuScreen extends Screen {
    private final ModuleManager modules;
    private final ConfigManager configs;

    public ReallyMainMenuScreen(ModuleManager modules, ConfigManager configs) {
        super(Text.literal("ReallyClient"));
        this.modules = modules;
        this.configs = configs;
    }

    @Override
    protected void init() {
        int w = 190;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 42;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§bREALLYWORLD"), b -> connectReallyWorld())
                .dimensions(x, y, w, 22).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Singleplayer"), b -> this.client.setScreen(new SelectWorldScreen(this)))
                .dimensions(x, y + 27, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Multiplayer"), b -> this.client.setScreen(new MultiplayerScreen(this)))
                .dimensions(x, y + 51, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("ReallyClient"), b -> this.client.setScreen(new ClickGuiScreen(modules, configs)))
                .dimensions(x, y + 75, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Options"), b -> this.client.setScreen(new OptionsScreen(this, this.client.options)))
                .dimensions(x, y + 99, 93, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Quit"), b -> this.client.scheduleStop())
                .dimensions(x + 97, y + 99, 93, 20).build());
    }

    private void connectReallyWorld() {
        String address = "mc.reallyworld.me";
        ServerInfo info = new ServerInfo("ReallyWorld", address, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, this.client, ServerAddress.parse(address), info, false, null);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        int h = Math.max(1, this.height);
        for (int y = 0; y < this.height; y += 6) {
            float t = y / (float) h;
            int r = (int) (7 + 8 * t);
            int g = (int) (11 + 14 * t);
            int b = (int) (19 + 26 * t);
            int color = 0xFF000000 | (r << 16) | (g << 8) | b;
            context.fill(0, y, this.width, Math.min(this.height, y + 6), color);
        }
        int accent = configs.get().accentColor;
        context.fill(this.width / 2 - 125, 34, this.width / 2 + 125, 37, accent);
        context.drawCenteredTextWithShadow(this.textRenderer, "§lREALLYCLIENT", this.width / 2, 48, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "Fabric 1.21.11 • ReallyWorld edition", this.width / 2, 62, 0xFF9EAFBF);
        context.drawTextWithShadow(this.textRenderer, "Profile: " + configs.activeProfile(), 10, this.height - 16, 0xFF7F91A4);
        super.render(context, mouseX, mouseY, deltaTicks);
    }
}
