package me.reallyclient.client.gui;

import me.reallyclient.client.config.ConfigManager;
import me.reallyclient.client.core.Category;
import me.reallyclient.client.core.Module;
import me.reallyclient.client.core.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public final class ClickGuiScreen extends Screen {
    private final ModuleManager modules;
    private final ConfigManager configs;
    private Category selected;

    public ClickGuiScreen(ModuleManager modules, ConfigManager configs) {
        this(modules, configs, Category.SERVER);
    }

    public ClickGuiScreen(ModuleManager modules, ConfigManager configs, Category selected) {
        super(Text.literal("ReallyClient"));
        this.modules = modules;
        this.configs = configs;
        this.selected = selected;
    }

    @Override
    protected void init() {
        int left = 24;
        int top = 42;
        int categoryWidth = 94;
        int i = 0;
        for (Category category : Category.values()) {
            int y = top + i * 24;
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal((category == selected ? "§b» " : "") + category.title()),
                    b -> {
                        selected = category;
                        clearAndInit();
                    }).dimensions(left, y, categoryWidth, 20).build());
            i++;
        }

        List<Module> list = modules.byCategory(selected);
        int startX = left + categoryWidth + 18;
        int startY = top;
        int colWidth = 180;
        for (int index = 0; index < list.size(); index++) {
            Module module = list.get(index);
            int col = index / 8;
            int row = index % 8;
            int x = startX + col * (colWidth + 8);
            int y = startY + row * 25;
            String state = module.enabled() ? "§aON" : "§cOFF";
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal(module.name() + "  " + state),
                    b -> {
                        module.toggle();
                        configs.save();
                        clearAndInit();
                    }).dimensions(x, y, colWidth, 21).build());
        }

        int bottomY = this.height - 30;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Profile: " + configs.activeProfile()), b -> cycleProfile())
                .dimensions(24, bottomY, 150, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Settings"), b -> this.client.setScreen(new ReallySettingsScreen(this, configs)))
                .dimensions(180, bottomY, 100, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> configs.save())
                .dimensions(286, bottomY, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(this.width - 94, bottomY, 70, 20).build());
    }

    private void cycleProfile() {
        List<String> profiles = configs.starterProfiles();
        int idx = profiles.indexOf(configs.activeProfile());
        idx = (idx + 1) % profiles.size();
        configs.load(profiles.get(idx));
        clearAndInit();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        int panel = configs.get().panelColor;
        context.fill(0, 0, this.width, this.height, 0xEC090D14);
        context.fill(12, 12, this.width - 12, this.height - 12, panel);
        context.fill(12, 12, this.width - 12, 15, configs.get().accentColor);
        context.drawTextWithShadow(this.textRenderer, "ReallyClient §7/ §f" + selected.title(), 24, 22, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, "Right Shift • modular client for ReallyWorld", this.width - 264, 22, 0xFF92A2B6);

        List<Module> list = modules.byCategory(selected);
        if (!list.isEmpty()) {
            Module hovered = findHoveredModule(mouseX, mouseY, list);
            if (hovered != null) {
                context.drawTextWithShadow(this.textRenderer, hovered.description(), 382, this.height - 25, 0xFFC9D4E3);
            }
        }
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private Module findHoveredModule(int mouseX, int mouseY, List<Module> list) {
        int startX = 24 + 94 + 18;
        int startY = 42;
        int colWidth = 180;
        for (int index = 0; index < list.size(); index++) {
            int col = index / 8;
            int row = index % 8;
            int x = startX + col * (colWidth + 8);
            int y = startY + row * 25;
            if (mouseX >= x && mouseX <= x + colWidth && mouseY >= y && mouseY <= y + 21) return list.get(index);
        }
        return null;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        configs.save();
        super.removed();
    }
}
