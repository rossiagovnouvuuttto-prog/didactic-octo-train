package me.reallyclient.client.mixin;

import me.reallyclient.client.ReallyClient;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(SkyRendering.class)
public abstract class SkyRenderingMixin {
    @ModifyVariable(method = "renderTopSky(I)V", at = @At("HEAD"), argsOnly = true)
    private int reallyclient$customSkyColor(int original) {
        if (ReallyClient.isModuleEnabled("skyoverlay") && ReallyClient.configs() != null) {
            return ReallyClient.configs().get().skyColor;
        }
        return original;
    }
}
