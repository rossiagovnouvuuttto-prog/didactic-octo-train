package me.reallyclient.client.service;

import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.RichPresence;
import me.reallyclient.client.config.ClientConfig;
import org.slf4j.Logger;

import java.time.OffsetDateTime;

public final class DiscordRpcService {
    private final Logger logger;
    private IPCClient client;
    private boolean connected;

    public DiscordRpcService(Logger logger) {
        this.logger = logger;
    }

    public void start(ClientConfig config) {
        if (connected || client != null) return;
        if (config.discordApplicationId <= 0L) {
            logger.info("Discord RPC is enabled, but discordApplicationId is 0. Set it in config/reallyclient/profile_*.json");
            return;
        }
        try {
            client = new IPCClient(config.discordApplicationId);
            client.setListener(new IPCListener() {
                @Override
                public void onReady(IPCClient ipcClient) {
                    connected = true;
                    update(config);
                }
            });
            client.connect();
        } catch (Throwable t) {
            logger.warn("Discord RPC connection failed", t);
            client = null;
            connected = false;
        }
    }

    public void update(ClientConfig config) {
        if (!connected || client == null) return;
        try {
            RichPresence presence = new RichPresence.Builder()
                    .setDetails(config.discordDetails)
                    .setState(config.discordState)
                    .setStartTimestamp(OffsetDateTime.now())
                    .build();
            client.sendRichPresence(presence);
        } catch (Throwable t) {
            logger.debug("Discord RPC update failed", t);
        }
    }

    public void stop() {
        if (client == null) return;
        try {
            client.close();
        } catch (Throwable ignored) {
        }
        client = null;
        connected = false;
    }
}
