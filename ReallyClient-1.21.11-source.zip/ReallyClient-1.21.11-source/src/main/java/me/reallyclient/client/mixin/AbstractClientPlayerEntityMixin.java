package me.reallyclient.client.mixin;

import me.reallyclient.client.ReallyClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    private static final AssetInfo.TextureAssetInfo REALLYCLIENT_CAPE = new AssetInfo.TextureAssetInfo(
            Identifier.of("reallyclient", "cape"),
            Identifier.of("reallyclient", "textures/entity/reallyclient_cape.png")
    );

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void reallyclient$localCape(CallbackInfoReturnable<SkinTextures> cir) {
        if (!ReallyClient.isModuleEnabled("cape")) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || (Object) this != client.player) return;

        SkinTextures original = cir.getReturnValue();
        if (original == null) return;
        cir.setReturnValue(new SkinTextures(
                original.body(),
                REALLYCLIENT_CAPE,
                original.elytra(),
                original.model(),
                original.secure()
        ));
    }
}
