package me.reallyclient.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import me.reallyclient.client.core.Module;
import me.reallyclient.client.core.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path root = FabricLoader.getInstance().getConfigDir().resolve("reallyclient");
    private final Path activeProfileFile = root.resolve("active_profile.txt");
    private final Logger logger;
    private final ModuleManager modules;

    private String activeProfile = "default";
    private ClientConfig config = new ClientConfig();

    public ConfigManager(Logger logger, ModuleManager modules) {
        this.logger = logger;
        this.modules = modules;
    }

    public void initialize() {
        try {
            Files.createDirectories(root);
            if (Files.exists(activeProfileFile)) {
                String s = Files.readString(activeProfileFile, StandardCharsets.UTF_8).trim();
                if (!s.isBlank()) activeProfile = sanitizeProfile(s);
            }
            load(activeProfile);
            ensureStarterProfiles();
        } catch (Exception e) {
            logger.error("Failed to initialize ReallyClient config", e);
            applyModuleStates();
        }
    }

    public ClientConfig get() {
        return config;
    }

    public String activeProfile() {
        return activeProfile;
    }

    public List<String> starterProfiles() {
        return List.of("default", "pvp", "visual", "performance");
    }

    public void load(String profile) {
        activeProfile = sanitizeProfile(profile);
        Path path = profilePath(activeProfile);
        try {
            if (Files.exists(path)) {
                ClientConfig loaded = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), ClientConfig.class);
                if (loaded != null) config = loaded;
            } else {
                config = template(activeProfile);
            }
            repairNulls();
            applyModuleStates();
            Files.writeString(activeProfileFile, activeProfile, StandardCharsets.UTF_8);
            save();
        } catch (Exception e) {
            logger.error("Failed to load profile {}", activeProfile, e);
        }
    }

    public void save() {
        try {
            for (Module module : modules.all()) {
                config.moduleStates.put(module.id(), module.enabled());
            }
            Files.createDirectories(root);
            Files.writeString(profilePath(activeProfile), GSON.toJson(config), StandardCharsets.UTF_8);
            Files.writeString(activeProfileFile, activeProfile, StandardCharsets.UTF_8);
        } catch (IOException e) {
            logger.error("Failed to save ReallyClient config", e);
        }
    }

    private void applyModuleStates() {
        for (Module module : modules.all()) {
            Boolean enabled = config.moduleStates.get(module.id());
            if (enabled != null) module.setEnabled(enabled);
            else config.moduleStates.put(module.id(), module.enabled());
        }
    }

    private void repairNulls() {
        if (config.moduleStates == null) config.moduleStates = new java.util.HashMap<>();
        if (config.autoCommands == null) config.autoCommands = new java.util.ArrayList<>();
        if (config.bannedWords == null) config.bannedWords = new java.util.ArrayList<>();
        if (config.afkBotNameFragments == null) config.afkBotNameFragments = new java.util.ArrayList<>();
        if (config.autoSellCommand == null) config.autoSellCommand = "/sell";
        if (config.discordDetails == null) config.discordDetails = "Playing ReallyWorld";
        if (config.discordState == null) config.discordState = "ReallyClient 1.21.11";
    }

    private void ensureStarterProfiles() {
        for (String name : starterProfiles()) {
            Path path = profilePath(name);
            if (!Files.exists(path)) {
                try {
                    Files.writeString(path, GSON.toJson(template(name)), StandardCharsets.UTF_8);
                } catch (IOException e) {
                    logger.warn("Couldn't create starter profile {}", name, e);
                }
            }
        }
    }

    private ClientConfig template(String profile) {
        ClientConfig c = new ClientConfig();
        for (Module module : modules.all()) {
            c.moduleStates.put(module.id(), module.defaultEnabled());
        }
        if ("pvp".equals(profile)) {
            c.moduleStates.put("aimfov", true);
            c.moduleStates.put("armorpinger", true);
            c.moduleStates.put("radar", true);
            c.moduleStates.put("cooldowns", true);
            c.moduleStates.put("near", true);
        } else if ("visual".equals(profile)) {
            c.moduleStates.put("fullbright", true);
            c.moduleStates.put("crosshair", true);
            c.moduleStates.put("chinesehat", true);
            c.moduleStates.put("pulse", true);
            c.moduleStates.put("jumpcircle", true);
        } else if ("performance".equals(profile)) {
            c.moduleStates.put("fpsboost", true);
            c.moduleStates.put("esp", false);
            c.moduleStates.put("blockpulse", false);
            c.moduleStates.put("chinesehat", false);
            c.moduleStates.put("pulse", false);
            c.moduleStates.put("radar", false);
        }
        return c;
    }

    private String sanitizeProfile(String name) {
        String cleaned = name.toLowerCase().replaceAll("[^a-z0-9_-]", "_");
        return cleaned.isBlank() ? "default" : cleaned;
    }

    private Path profilePath(String profile) {
        return root.resolve("profile_" + sanitizeProfile(profile) + ".json");
    }
}
