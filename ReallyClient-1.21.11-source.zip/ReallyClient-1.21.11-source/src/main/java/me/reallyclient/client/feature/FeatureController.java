package me.reallyclient.client.feature;

import me.reallyclient.client.config.ClientConfig;
import me.reallyclient.client.config.ConfigManager;
import me.reallyclient.client.core.ModuleManager;
import me.reallyclient.client.mixin.MinecraftClientAccessor;
import me.reallyclient.client.service.DiscordRpcService;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class FeatureController {
    private final ModuleManager modules;
    private final ConfigManager configs;
    private final InputTracker input;
    private final DiscordRpcService discord;

    private final Set<UUID> glowTouched = new HashSet<>();
    private final Set<UUID> hiddenAfk = new HashSet<>();
    private final Set<UUID> nearbyLastScan = new HashSet<>();
    private final Set<Integer> warnedArmorSlots = new HashSet<>();

    private boolean glowWasEnabled;
    private boolean hideAfkWasEnabled;
    private boolean discordWasEnabled;
    private boolean fullbrightApplied;
    private boolean wasOnGround = true;

    private int tick;
    private int blockScanCursor;
    private long lastAutoCommandAt;
    private long lastAutoSellAt;

    public FeatureController(ModuleManager modules, ConfigManager configs, InputTracker input, DiscordRpcService discord) {
        this.modules = modules;
        this.configs = configs;
        this.input = input;
        this.discord = discord;
    }

    public void tick(MinecraftClient client) {
        input.tick(client);
        tick++;
        ClientConfig cfg = configs.get();

        handleDiscord(cfg);

        if (client.player == null || client.world == null) {
            return;
        }

        handleFullbright(client);
        handleEsp(client);
        handleHideAfk(client, cfg);
        handleClientEnvironment(client, cfg);
        handleAimAssist(client, cfg);
        handleCrystalOptimizer(client);
        handleArmorPinger(client, cfg);
        handleNear(client, cfg);
        handleAntiRod(client);
        handleAutomation(client, cfg);
        handleParticles(client, cfg);
        handleVisibleBlockEsp(client, cfg);
    }

    public boolean allowOutgoingChat(String message, MinecraftClient client) {
        if (!modules.enabled("chatfilter")) return true;
        String normalized = normalize(message);
        for (String word : configs.get().bannedWords) {
            if (word == null || word.isBlank()) continue;
            if (normalized.contains(normalize(word))) {
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§c[ReallyClient] Сообщение заблокировано Chat Guard: §f" + word), false);
                    playAlert(client, 0.75f);
                }
                return false;
            }
        }
        return true;
    }

    public void onIncomingMessage(String raw, MinecraftClient client) {
        if (client.player == null || raw == null) return;
        if (!modules.enabled("nickping")) return;
        String username = client.getSession().getUsername();
        if (username == null || username.isBlank()) return;
        if (normalize(raw).contains(normalize(username))) {
            playAlert(client, 1.35f);
            client.player.sendMessage(Text.literal("§b[ReallyClient] §fТвой ник упомянули в чате."), false);
        }
    }

    private void handleDiscord(ClientConfig cfg) {
        boolean enabled = modules.enabled("discordrpc");
        if (enabled && !discordWasEnabled) discord.start(cfg);
        if (!enabled && discordWasEnabled) discord.stop();
        discordWasEnabled = enabled;
    }

    private void handleFullbright(MinecraftClient client) {
        boolean enabled = modules.enabled("fullbright");
        if (enabled) {
            if (!client.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 340, 0, false, false, false));
                fullbrightApplied = true;
            }
        } else if (fullbrightApplied) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightApplied = false;
        }
    }

    private void handleEsp(MinecraftClient client) {
        boolean enabled = modules.enabled("esp");
        if (enabled) {
            for (Entity entity : client.world.getEntities()) {
                if (entity == client.player) continue;
                if (entity instanceof PlayerEntity || entity instanceof MobEntity || entity instanceof ItemEntity) {
                    entity.setGlowing(true);
                    glowTouched.add(entity.getUuid());
                }
            }
        } else if (glowWasEnabled) {
            for (Entity entity : client.world.getEntities()) {
                if (glowTouched.contains(entity.getUuid())) entity.setGlowing(false);
            }
            glowTouched.clear();
        }
        glowWasEnabled = enabled;
    }

    private void handleHideAfk(MinecraftClient client, ClientConfig cfg) {
        boolean enabled = modules.enabled("hideafk");
        if (enabled) {
            for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
                if (player == client.player) continue;
                String name = normalize(player.getName().getString());
                if (matchesAnyFragment(name, cfg.afkBotNameFragments)) {
                    player.setInvisible(true);
                    hiddenAfk.add(player.getUuid());
                }
            }
        } else if (hideAfkWasEnabled) {
            for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
                if (hiddenAfk.contains(player.getUuid())) player.setInvisible(false);
            }
            hiddenAfk.clear();
        }
        hideAfkWasEnabled = enabled;
    }

    private void handleClientEnvironment(MinecraftClient client, ClientConfig cfg) {
        if (modules.enabled("worldtime")) {
            client.world.getLevelProperties().setTimeOfDay(cfg.fixedTimeOfDay);
        }
        if (modules.enabled("clearweather")) {
            client.world.setRainGradient(0.0f);
            client.world.setThunderGradient(0.0f);
        }
    }

    private void handleAimAssist(MinecraftClient client, ClientConfig cfg) {
        if (!modules.enabled("aimassist") || !client.options.attackKey.isPressed()) return;

        AbstractClientPlayerEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        Vec3d eye = client.player.getEyePos();

        for (AbstractClientPlayerEntity target : client.world.getPlayers()) {
            if (target == client.player || target.isRemoved() || !target.isAlive()) continue;
            double distSq = client.player.squaredDistanceTo(target);
            if (distSq > cfg.aimRange * cfg.aimRange) continue;

            Vec3d delta = target.getEyePos().subtract(eye);
            double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
            float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
            float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
            float yawDiff = MathHelper.wrapDegrees(targetYaw - client.player.getYaw());
            float pitchDiff = MathHelper.wrapDegrees(targetPitch - client.player.getPitch());
            double angle = Math.hypot(yawDiff, pitchDiff);
            if (angle <= cfg.aimFovDegrees && angle < bestAngle) {
                best = target;
                bestAngle = angle;
            }
        }

        if (best != null) {
            Vec3d delta = best.getEyePos().subtract(eye);
            double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
            float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
            float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
            float yawDiff = MathHelper.wrapDegrees(targetYaw - client.player.getYaw());
            float pitchDiff = MathHelper.wrapDegrees(targetPitch - client.player.getPitch());
            float smooth = (float) MathHelper.clamp(cfg.aimSmooth, 0.02, 1.0);
            client.player.setYaw(client.player.getYaw() + yawDiff * smooth);
            client.player.setPitch(MathHelper.clamp(client.player.getPitch() + pitchDiff * smooth, -90.0f, 90.0f));
        }
    }

    private void handleCrystalOptimizer(MinecraftClient client) {
        if (!modules.enabled("crystaloptimizer")) return;
        ((MinecraftClientAccessor) client).reallyclient$setItemUseCooldown(0);
    }

    private void handleArmorPinger(MinecraftClient client, ClientConfig cfg) {
        if (!modules.enabled("armorpinger") || tick % 10 != 0) return;
        int slot = 0;
        for (ItemStack stack : client.player.getArmorItems()) {
            if (!stack.isEmpty() && stack.isDamageable()) {
                int remaining = stack.getMaxDamage() - stack.getDamage();
                int percent = (int) Math.round(remaining * 100.0 / Math.max(1, stack.getMaxDamage()));
                if (percent <= cfg.armorWarningPercent) {
                    if (warnedArmorSlots.add(slot)) {
                        playAlert(client, 1.55f);
                        client.player.sendMessage(Text.literal("§c[ReallyClient] Броня почти сломана: §f" + percent + "%"), false);
                    }
                } else if (percent > cfg.armorWarningPercent + 5) {
                    warnedArmorSlots.remove(slot);
                }
            } else {
                warnedArmorSlots.remove(slot);
            }
            slot++;
        }
    }

    private void handleNear(MinecraftClient client, ClientConfig cfg) {
        if (!modules.enabled("near") || tick % 20 != 0) return;
        Set<UUID> now = new HashSet<>();
        double maxSq = cfg.nearRange * (double) cfg.nearRange;
        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (player == client.player || player.isRemoved()) continue;
            double distSq = client.player.squaredDistanceTo(player);
            if (distSq <= maxSq) {
                now.add(player.getUuid());
                if (!nearbyLastScan.contains(player.getUuid())) {
                    int distance = (int) Math.round(Math.sqrt(distSq));
                    client.player.sendMessage(Text.literal("§e[Near] §f" + player.getName().getString() + " §7вошёл в радиус: §b" + distance + "м"), false);
                    playAlert(client, 1.15f);
                }
            }
        }
        nearbyLastScan.clear();
        nearbyLastScan.addAll(now);
    }

    private void handleAntiRod(MinecraftClient client) {
        if (!modules.enabled("antirod") || !input.isMovementIdle(client)) return;
        for (Entity entity : client.world.getEntities()) {
            if (entity instanceof FishingBobberEntity && client.player.squaredDistanceTo(entity) < 16.0) {
                Vec3d v = client.player.getVelocity();
                client.player.setVelocity(0.0, v.y, 0.0);
                break;
            }
        }
    }

    private void handleAutomation(MinecraftClient client, ClientConfig cfg) {
        long now = System.currentTimeMillis();
        if (modules.enabled("autocommand") && now - lastAutoCommandAt >= Math.max(1, cfg.autoCommandIntervalSeconds) * 1000L) {
            for (String command : cfg.autoCommands) sendCommand(client, command);
            lastAutoCommandAt = now;
        }
        if (modules.enabled("autosell") && now - lastAutoSellAt >= Math.max(1, cfg.autoSellIntervalSeconds) * 1000L) {
            sendCommand(client, cfg.autoSellCommand);
            lastAutoSellAt = now;
        }
    }

    private void handleParticles(MinecraftClient client, ClientConfig cfg) {
        boolean fps = modules.enabled("fpsboost");
        int cosmeticCadence = fps ? 8 : 4;

        boolean onGround = client.player.isOnGround();
        if (modules.enabled("jumpcircle") && wasOnGround && !onGround && client.player.getVelocity().y > 0.08) {
            particleRing(client, client.player.getX(), client.player.getY() + 0.05, client.player.getZ(), 1.2, fps ? 18 : 32);
        }
        wasOnGround = onGround;

        if (modules.enabled("pulse") && tick % (fps ? 60 : 36) == 0) {
            particleRing(client, client.player.getX(), client.player.getY() + 0.1, client.player.getZ(), 2.1, fps ? 20 : 40);
        }

        if (modules.enabled("radiuspreview") && tick % (fps ? 40 : 20) == 0) {
            particleRing(client, client.player.getX(), client.player.getY() + 0.08, client.player.getZ(), Math.max(1, cfg.abilityRadius), fps ? 28 : 56);
        }

        if (modules.enabled("chinesehat") && tick % cosmeticCadence == 0) {
            double baseY = client.player.getY() + client.player.getHeight() + 0.18;
            particleRing(client, client.player.getX(), baseY, client.player.getZ(), 0.55, fps ? 12 : 22);
            particleRing(client, client.player.getX(), baseY + 0.16, client.player.getZ(), 0.34, fps ? 8 : 16);
            client.world.addParticleClient(ParticleTypes.END_ROD, client.player.getX(), baseY + 0.38, client.player.getZ(), 0, 0, 0);
        }
    }

    private void handleVisibleBlockEsp(MinecraftClient client, ClientConfig cfg) {
        if (!modules.enabled("blockpulse")) return;
        int cadence = modules.enabled("fpsboost") ? 4 : 2;
        if (tick % cadence != 0) return;

        int rx = Math.max(2, Math.min(32, cfg.blockScanRadius));
        int ry = Math.max(2, Math.min(24, cfg.blockScanVertical));
        int sx = rx * 2 + 1;
        int sy = ry * 2 + 1;
        int total = sx * sy * sx;
        int budget = Math.max(50, Math.min(2500, cfg.blockScanBudgetPerTick));
        BlockPos origin = client.player.getBlockPos();

        for (int n = 0; n < budget; n++) {
            int idx = Math.floorMod(blockScanCursor++, total);
            int xIndex = idx % sx;
            int yIndex = (idx / sx) % sy;
            int zIndex = idx / (sx * sy);
            int dx = xIndex - rx;
            int dy = yIndex - ry;
            int dz = zIndex - rx;
            BlockPos pos = new BlockPos(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
            BlockState state = client.world.getBlockState(pos);
            if (isInterestingOre(state) && isExposed(client, pos)) {
                client.world.addParticleClient(ParticleTypes.END_ROD,
                        pos.getX() + 0.5, pos.getY() + 0.55, pos.getZ() + 0.5,
                        0.0, 0.004, 0.0);
            }
        }
    }

    private boolean isInterestingOre(BlockState state) {
        return state.isOf(Blocks.DIAMOND_ORE)
                || state.isOf(Blocks.DEEPSLATE_DIAMOND_ORE)
                || state.isOf(Blocks.EMERALD_ORE)
                || state.isOf(Blocks.DEEPSLATE_EMERALD_ORE)
                || state.isOf(Blocks.ANCIENT_DEBRIS)
                || state.isOf(Blocks.GOLD_ORE)
                || state.isOf(Blocks.DEEPSLATE_GOLD_ORE)
                || state.isOf(Blocks.NETHER_GOLD_ORE);
    }

    private boolean isExposed(MinecraftClient client, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockState neighbor = client.world.getBlockState(pos.offset(direction));
            if (neighbor.isAir() || !neighbor.getFluidState().isEmpty()) return true;
        }
        return false;
    }

    private void particleRing(MinecraftClient client, double x, double y, double z, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            client.world.addParticleClient(ParticleTypes.END_ROD,
                    x + Math.cos(angle) * radius,
                    y,
                    z + Math.sin(angle) * radius,
                    0.0, 0.002, 0.0);
        }
    }

    private void sendCommand(MinecraftClient client, String raw) {
        if (raw == null || raw.isBlank() || client.getNetworkHandler() == null) return;
        String command = raw.startsWith("/") ? raw.substring(1) : raw;
        client.getNetworkHandler().sendChatCommand(command);
    }

    private void playAlert(MinecraftClient client, float pitch) {
        client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING, pitch));
    }

    private boolean matchesAnyFragment(String name, Iterable<String> fragments) {
        for (String fragment : fragments) {
            if (fragment != null && !fragment.isBlank() && name.contains(normalize(fragment))) return true;
        }
        return false;
    }

    private String normalize(String text) {
        return text.toLowerCase(Locale.ROOT).replace('ё', 'е');
    }
}
