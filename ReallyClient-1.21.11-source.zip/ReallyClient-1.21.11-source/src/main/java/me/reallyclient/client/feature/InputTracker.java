package me.reallyclient.client.feature;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;

public final class InputTracker {
    private final Deque<Long> clicks = new ArrayDeque<>();
    private boolean attackWasDown;

    public void tick(MinecraftClient client) {
        long now = System.currentTimeMillis();
        boolean down = client.options.attackKey.isPressed();
        if (down && !attackWasDown) {
            clicks.addLast(now);
        }
        attackWasDown = down;
        while (!clicks.isEmpty() && clicks.peekFirst() < now - 1000L) {
            clicks.removeFirst();
        }
    }

    public int cps() {
        return clicks.size();
    }

    public boolean isMovementIdle(MinecraftClient client) {
        return !client.options.forwardKey.isPressed()
                && !client.options.backKey.isPressed()
                && !client.options.leftKey.isPressed()
                && !client.options.rightKey.isPressed()
                && !client.options.jumpKey.isPressed();
    }
}
