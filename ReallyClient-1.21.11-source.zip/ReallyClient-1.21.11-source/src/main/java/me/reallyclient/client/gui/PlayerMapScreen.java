package me.reallyclient.client.gui;

import me.reallyclient.client.config.ConfigManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.text.Text;

public final class PlayerMapScreen extends Screen {
    private final ConfigManager configs;

    public PlayerMapScreen(ConfigManager configs) {
        super(Text.literal("ReallyClient Player Map"));
        this.configs = configs;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, width, height, 0xF40A0D14);
        int margin = 22;
        int left = margin;
        int top = 34;
        int right = width - margin;
        int bottom = height - margin;
        int accent = configs.get().accentColor;

        context.fill(left, top, right, bottom, 0xD9121721);
        context.fill(left, top, right, top + 2, accent);
        context.drawCenteredTextWithShadow(textRenderer, "PLAYER MAP", width / 2, 13, 0xFFFFFFFF);

        int centerX = (left + right) / 2;
        int centerY = (top + bottom) / 2;
        for (int gx = centerX; gx < right; gx += 24) context.fill(gx, top, gx + 1, bottom, 0x223A4B5F);
        for (int gx = centerX; gx > left; gx -= 24) context.fill(gx, top, gx + 1, bottom, 0x223A4B5F);
        for (int gy = centerY; gy < bottom; gy += 24) context.fill(left, gy, right, gy + 1, 0x223A4B5F);
        for (int gy = centerY; gy > top; gy -= 24) context.fill(left, gy, right, gy + 1, 0x223A4B5F);

        if (client == null || client.player == null || client.world == null) {
            super.render(context, mouseX, mouseY, deltaTicks);
            return;
        }

        context.fill(centerX - 3, centerY - 3, centerX + 4, centerY + 4, 0xFFFFFFFF);
        int range = Math.max(64, configs.get().radarRange * 4);
        double scaleX = (right - left - 24) / (range * 2.0);
        double scaleY = (bottom - top - 24) / (range * 2.0);

        for (AbstractClientPlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || p.isRemoved()) continue;
            double dx = p.getX() - client.player.getX();
            double dz = p.getZ() - client.player.getZ();
            if (Math.abs(dx) > range || Math.abs(dz) > range) continue;
            int px = centerX + (int) Math.round(dx * scaleX);
            int py = centerY + (int) Math.round(dz * scaleY);
            context.fill(px - 2, py - 2, px + 3, py + 3, accent);
            context.drawTextWithShadow(textRenderer, p.getName().getString(), px + 5, py - 4, 0xFFEAF2FF);
        }

        String coords = String.format("X %.0f  Z %.0f  •  range %dm", client.player.getX(), client.player.getZ(), range);
        context.drawTextWithShadow(textRenderer, coords, left + 7, bottom - 14, 0xFF9EB0C4);
        context.drawTextWithShadow(textRenderer, "ESC — close", right - 82, bottom - 14, 0xFF7F91A4);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
