package me.reallyclient.client.gui;

import me.reallyclient.client.config.ClientConfig;
import me.reallyclient.client.config.ConfigManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ReallySettingsScreen extends Screen {
    private final Screen parent;
    private final ConfigManager configs;

    public ReallySettingsScreen(Screen parent, ConfigManager configs) {
        super(Text.literal("ReallyClient Settings"));
        this.parent = parent;
        this.configs = configs;
    }

    @Override
    protected void init() {
        ClientConfig c = configs.get();
        int x = this.width / 2 - 160;
        int y = 48;

        addPair(x, y, "Aim FOV: " + fmt(c.aimFovDegrees), () -> c.aimFovDegrees = Math.max(2, c.aimFovDegrees - 2), () -> c.aimFovDegrees = Math.min(90, c.aimFovDegrees + 2));
        addPair(x, y + 28, "Aim range: " + fmt(c.aimRange), () -> c.aimRange = Math.max(2, c.aimRange - 0.5), () -> c.aimRange = Math.min(12, c.aimRange + 0.5));
        addPair(x, y + 56, "Aim smooth: " + fmt(c.aimSmooth), () -> c.aimSmooth = Math.max(0.02, c.aimSmooth - 0.05), () -> c.aimSmooth = Math.min(1, c.aimSmooth + 0.05));
        addPair(x, y + 84, "Radar: " + c.radarRange + "m", () -> c.radarRange = Math.max(16, c.radarRange - 8), () -> c.radarRange = Math.min(256, c.radarRange + 8));
        addPair(x, y + 112, "Near: " + c.nearRange + "m", () -> c.nearRange = Math.max(8, c.nearRange - 8), () -> c.nearRange = Math.min(256, c.nearRange + 8));
        addPair(x, y + 140, "Armor warn: " + c.armorWarningPercent + "%", () -> c.armorWarningPercent = Math.max(5, c.armorWarningPercent - 5), () -> c.armorWarningPercent = Math.min(80, c.armorWarningPercent + 5));
        addPair(x, y + 168, "Radius preview: " + c.abilityRadius, () -> c.abilityRadius = Math.max(1, c.abilityRadius - 1), () -> c.abilityRadius = Math.min(32, c.abilityRadius + 1));
        addPair(x, y + 196, "Zoom FOV: " + (int)c.zoomFov, () -> c.zoomFov = Math.max(5, c.zoomFov - 5), () -> c.zoomFov = Math.min(70, c.zoomFov + 5));
        addPair(x, y + 224, "Time: " + c.fixedTimeOfDay, () -> c.fixedTimeOfDay = Math.floorMod(c.fixedTimeOfDay - 1000L, 24000L), () -> c.fixedTimeOfDay = Math.floorMod(c.fixedTimeOfDay + 1000L, 24000L));
        addPair(x, y + 252, "Sky: " + rgbHex(c.skyColor), () -> shiftSkyHue(c, -0.04f), () -> shiftSkyHue(c, 0.04f));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> {
            configs.save();
            this.client.setScreen(parent);
        }).dimensions(this.width / 2 - 50, this.height - 34, 100, 20).build());
    }

    private void addPair(int x, int y, String label, Runnable minus, Runnable plus) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("−"), b -> { minus.run(); clearAndInit(); })
                .dimensions(x, y, 36, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {})
                .dimensions(x + 42, y, 236, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { plus.run(); clearAndInit(); })
                .dimensions(x + 284, y, 36, 20).build());
    }

    private String fmt(double v) {
        return String.format("%.2f", v);
    }

    private String rgbHex(int argb) {
        return String.format("#%06X", argb & 0xFFFFFF);
    }

    private void shiftSkyHue(ClientConfig c, float delta) {
        int rgb = c.skyColor & 0xFFFFFF;
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        float[] hsb = java.awt.Color.RGBtoHSB(r, g, b, null);
        float hue = hsb[0] + delta;
        if (hue < 0) hue += 1.0f;
        if (hue >= 1.0f) hue -= 1.0f;
        c.skyColor = 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, Math.max(0.45f, hsb[1]), Math.max(0.45f, hsb[2])) & 0xFFFFFF);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, this.width, this.height, 0xF00A0D14);
        context.fill(10, 10, this.width - 10, 13, configs.get().accentColor);
        context.drawCenteredTextWithShadow(this.textRenderer, "ReallyClient Settings", this.width / 2, 22, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public void close() {
        configs.save();
        this.client.setScreen(parent);
    }
}
