package me.reallyclient.client.mixin;

import me.reallyclient.client.ReallyClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(
            method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At("HEAD")
    )
    private void reallyclient$pushViewModel(float tickProgress, MatrixStack matrices,
                                            OrderedRenderCommandQueue queue, ClientPlayerEntity player,
                                            int light, CallbackInfo ci) {
        if (!ReallyClient.isModuleEnabled("viewmodel")) return;
        matrices.push();
        matrices.translate(0.08f, -0.06f, -0.10f);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-5.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(4.0f));
    }

    @Inject(
            method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At("RETURN")
    )
    private void reallyclient$popViewModel(float tickProgress, MatrixStack matrices,
                                           OrderedRenderCommandQueue queue, ClientPlayerEntity player,
                                           int light, CallbackInfo ci) {
        if (ReallyClient.isModuleEnabled("viewmodel")) matrices.pop();
    }
}
