package me.reallyclient.client;

import me.reallyclient.client.config.ConfigManager;
import me.reallyclient.client.core.ModuleManager;
import me.reallyclient.client.feature.FeatureController;
import me.reallyclient.client.feature.InputTracker;
import me.reallyclient.client.gui.ClickGuiScreen;
import me.reallyclient.client.gui.PlayerMapScreen;
import me.reallyclient.client.gui.ReallyMainMenuScreen;
import me.reallyclient.client.hud.HudRenderer;
import me.reallyclient.client.service.DiscordRpcService;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ReallyClient implements ClientModInitializer {
    public static final String MOD_ID = "reallyclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ModuleManager modules;
    private static ConfigManager configs;
    private static FeatureController features;
    private static HudRenderer hud;

    private static KeyBinding menuKey;
    private static KeyBinding zoomKey;
    private static KeyBinding mapKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        configs = new ConfigManager(LOGGER, modules);
        configs.initialize();

        InputTracker input = new InputTracker();
        DiscordRpcService discord = new DiscordRpcService(LOGGER);
        features = new FeatureController(modules, configs, input, discord);
        hud = new HudRenderer(modules, configs, input);

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.reallyclient.menu", InputUtil.Type.KEYSYM, InputUtil.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.reallyclient.zoom", InputUtil.Type.KEYSYM, InputUtil.GLFW_KEY_C, KeyBinding.Category.MISC));
        mapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.reallyclient.map", InputUtil.Type.KEYSYM, InputUtil.GLFW_KEY_M, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);

        // Kept for 1.21.11 compatibility. Fabric marks this callback deprecated in favor of HudElementRegistry,
        // but it remains functional and keeps this starter source compact.
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> hud.render(drawContext, MinecraftClient.getInstance()));

        ClientSendMessageEvents.ALLOW_CHAT.register(message ->
                features.allowOutgoingChat(message, MinecraftClient.getInstance()));
        ClientReceiveMessageEvents.GAME.register((message, overlay) ->
                features.onIncomingMessage(message.getString(), MinecraftClient.getInstance()));
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                features.onIncomingMessage(message.getString(), MinecraftClient.getInstance()));

        LOGGER.info("ReallyClient initialized for Minecraft 1.21.11");
    }

    private void onEndTick(MinecraftClient client) {
        if (menuKey.wasPressed()) {
            if (client.currentScreen instanceof ClickGuiScreen) {
                client.setScreen(null);
            } else if (client.currentScreen == null) {
                client.setScreen(new ClickGuiScreen(modules, configs));
            }
        }

        if (mapKey.wasPressed() && client.currentScreen == null && client.player != null && client.world != null) {
            client.setScreen(new PlayerMapScreen(configs));
        }

        if (client.currentScreen instanceof TitleScreen && configs.get().replaceMainMenu) {
            client.setScreen(new ReallyMainMenuScreen(modules, configs));
        }

        features.tick(client);
    }

    public static boolean isModuleEnabled(String id) {
        return modules != null && modules.enabled(id);
    }

    public static ConfigManager configs() {
        return configs;
    }

    public static boolean isZoomHeld() {
        return zoomKey != null && zoomKey.isPressed() && isModuleEnabled("zoom");
    }
}
