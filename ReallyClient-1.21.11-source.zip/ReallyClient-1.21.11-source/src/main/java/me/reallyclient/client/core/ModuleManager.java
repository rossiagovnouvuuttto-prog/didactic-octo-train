package me.reallyclient.client.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // HUD
        add("hud", "Main HUD", "FPS, coordinates and ping", Category.HUD, true);
        add("keystrokes", "Keystrokes", "WASD, jump and mouse keys", Category.HUD, true);
        add("cps", "CPS", "Clicks per second", Category.HUD, true);
        add("crosshair", "Custom Crosshair", "Custom client-side crosshair", Category.HUD, true);
        add("cooldowns", "Cooldown Panel", "Vanilla item cooldowns and configured timers", Category.HUD, true);
        add("radar", "Player Radar", "2D radar with nearby players", Category.HUD, true);

        // Visuals
        add("fullbright", "FullBright", "Client-side night vision", Category.VISUAL, false);
        add("esp", "ESP / Glow", "Client-side glow for players, mobs and items", Category.VISUAL, false);
        add("blockpulse", "Visible Block ESP", "Highlights exposed ores only; not X-Ray", Category.VISUAL, false);
        add("worldtime", "Client Time", "Fixes client-side world time", Category.VISUAL, false);
        add("clearweather", "Clear Weather", "Hides rain and thunder client-side", Category.VISUAL, false);
        add("skyoverlay", "Custom Sky", "Recolors the rendered sky with a configurable hue", Category.VISUAL, false);
        add("viewmodel", "ViewModel", "Aggressive first-person hand feel", Category.VISUAL, false);
        add("radiuspreview", "Radius Preview", "Particle preview of configured ability radius", Category.VISUAL, false);

        // PvP
        add("zoom", "Zoom", "Hold zoom key for low FOV", Category.COMBAT, true);
        add("aimassist", "Aim Assist", "Smooth aim correction inside FOV; no auto attack", Category.COMBAT, false);
        add("aimfov", "Aim FOV Circle", "Shows the aim-assist FOV", Category.COMBAT, false);
        add("crystaloptimizer", "Crystal Optimizer", "Reduces client item-use cooldown", Category.COMBAT, false);
        add("armorpinger", "Armor Pinger", "Alerts on critical armor durability", Category.COMBAT, true);
        add("jumpcircle", "Jump Circle", "Particle ring on jump", Category.COMBAT, false);

        // Server / ReallyWorld utilities
        add("chatfilter", "Chat Guard", "Blocks messages containing configured banwords", Category.SERVER, true);
        add("nickping", "Nick Ping", "Sound + chat alert when your nickname is mentioned", Category.SERVER, true);
        add("antirod", "Anti Rod AFK", "Cancels horizontal fishing-rod pull while idle", Category.SERVER, false);
        add("hideafk", "Hide AFK Bots", "Hides players matching configured AFK-bot patterns", Category.SERVER, false);
        add("near", "Near Scanner", "Alerts when players enter configured radius", Category.SERVER, true);
        add("samechunk", "Free Near", "Same-chunk players, direction and distance", Category.SERVER, true);
        add("autocommand", "Auto Command", "Runs configured server commands on timer", Category.SERVER, false);
        add("autosell", "AutoSell", "Runs a configurable sell command on timer", Category.SERVER, false);

        // Utility / cosmetics
        add("fpsboost", "FPS Boost", "Throttles ReallyClient's expensive scanners/effects", Category.UTILITY, true);
        add("discordrpc", "Discord RPC", "Rich Presence through local Discord IPC", Category.UTILITY, false);
        add("cape", "ReallyClient Cape", "Local custom cape visible on your player", Category.COSMETIC, false);
        add("chinesehat", "Chinese Hat", "Local particle hat cosmetic", Category.COSMETIC, false);
        add("pulse", "Pulse", "Periodic local particle pulse", Category.COSMETIC, false);
    }

    private void add(String id, String name, String description, Category category, boolean enabled) {
        modules.add(new Module(id, name, description, category, enabled));
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> byCategory(Category category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }

    public Module get(String id) {
        String key = id.toLowerCase(Locale.ROOT);
        return modules.stream().filter(m -> m.id().equals(key)).findFirst().orElseThrow();
    }

    public boolean enabled(String id) {
        return get(id).enabled();
    }
}
