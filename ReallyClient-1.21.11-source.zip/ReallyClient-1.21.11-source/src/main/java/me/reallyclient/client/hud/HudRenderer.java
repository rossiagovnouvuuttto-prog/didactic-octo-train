package me.reallyclient.client.hud;

import me.reallyclient.client.config.ClientConfig;
import me.reallyclient.client.config.ConfigManager;
import me.reallyclient.client.core.ModuleManager;
import me.reallyclient.client.feature.InputTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public final class HudRenderer {
    private final ModuleManager modules;
    private final ConfigManager configs;
    private final InputTracker input;

    public HudRenderer(ModuleManager modules, ConfigManager configs, InputTracker input) {
        this.modules = modules;
        this.configs = configs;
        this.input = input;
    }

    public void render(DrawContext context, MinecraftClient client) {
        if (client.player == null || client.world == null || client.options.hudHidden) return;
        ClientConfig cfg = configs.get();
        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();


        if (modules.enabled("hud")) drawMainHud(context, client, cfg);
        if (modules.enabled("keystrokes")) drawKeystrokes(context, client, height, cfg);
        if (modules.enabled("cps")) drawCps(context, client, height, cfg);
        if (modules.enabled("crosshair")) drawCrosshair(context, width, height, cfg);
        if (modules.enabled("radar")) drawRadar(context, client, width, cfg);
        if (modules.enabled("samechunk")) drawSameChunk(context, client, width, cfg);
        if (modules.enabled("cooldowns")) drawCooldowns(context, client, width, height, cfg);
        if (modules.enabled("aimfov")) drawAimFov(context, width, height, cfg);
    }

    private void drawMainHud(DrawContext ctx, MinecraftClient client, ClientConfig cfg) {
        int x = 8;
        int y = 8;
        int ping = -1;
        if (client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }
        String line1 = "ReallyClient §7| §f" + client.getCurrentFps() + " FPS §7| §f" + (ping < 0 ? "?" : ping) + " ms";
        String line2 = String.format("XYZ §f%.1f %.1f %.1f", client.player.getX(), client.player.getY(), client.player.getZ());
        int w = Math.max(client.textRenderer.getWidth(line1), client.textRenderer.getWidth(line2)) + 12;
        ctx.fill(x - 4, y - 4, x + w, y + 24, cfg.panelColor);
        ctx.fill(x - 4, y - 4, x - 1, y + 24, cfg.accentColor);
        ctx.drawTextWithShadow(client.textRenderer, line1, x, y, 0xFFFFFFFF);
        ctx.drawTextWithShadow(client.textRenderer, line2, x, y + 11, 0xFFB8C7D9);
    }

    private void drawKeystrokes(DrawContext ctx, MinecraftClient client, int height, ClientConfig cfg) {
        int size = 22;
        int gap = 2;
        int x = 8;
        int y = height - 82;
        key(ctx, client, "W", x + size + gap, y, size, client.options.forwardKey.isPressed(), cfg);
        key(ctx, client, "A", x, y + size + gap, size, client.options.leftKey.isPressed(), cfg);
        key(ctx, client, "S", x + size + gap, y + size + gap, size, client.options.backKey.isPressed(), cfg);
        key(ctx, client, "D", x + (size + gap) * 2, y + size + gap, size, client.options.rightKey.isPressed(), cfg);
        key(ctx, client, "SPACE", x, y + (size + gap) * 2, size * 3 + gap * 2, client.options.jumpKey.isPressed(), cfg);
    }

    private void drawCps(DrawContext ctx, MinecraftClient client, int height, ClientConfig cfg) {
        String text = input.cps() + " CPS";
        int x = 8;
        int y = height - 104;
        int w = client.textRenderer.getWidth(text) + 10;
        ctx.fill(x - 3, y - 3, x + w, y + 11, cfg.panelColor);
        ctx.drawTextWithShadow(client.textRenderer, text, x + 2, y, 0xFFFFFFFF);
    }

    private void key(DrawContext ctx, MinecraftClient client, String text, int x, int y, int width, boolean pressed, ClientConfig cfg) {
        int bg = pressed ? cfg.accentColor : cfg.panelColor;
        ctx.fill(x, y, x + width, y + 20, bg);
        int color = pressed ? 0xFF07111A : 0xFFFFFFFF;
        int tx = x + (width - client.textRenderer.getWidth(text)) / 2;
        ctx.drawTextWithShadow(client.textRenderer, text, tx, y + 6, color);
    }

    private void drawCrosshair(DrawContext ctx, int width, int height, ClientConfig cfg) {
        int cx = width / 2;
        int cy = height / 2;
        int c = cfg.accentColor;
        ctx.fill(cx - 7, cy, cx - 2, cy + 1, 0xFF000000);
        ctx.fill(cx + 3, cy, cx + 8, cy + 1, 0xFF000000);
        ctx.fill(cx, cy - 7, cx + 1, cy - 2, 0xFF000000);
        ctx.fill(cx, cy + 3, cx + 1, cy + 8, 0xFF000000);
        ctx.fill(cx - 6, cy, cx - 2, cy + 1, c);
        ctx.fill(cx + 3, cy, cx + 7, cy + 1, c);
        ctx.fill(cx, cy - 6, cx + 1, cy - 2, c);
        ctx.fill(cx, cy + 3, cx + 1, cy + 7, c);
    }

    private void drawRadar(DrawContext ctx, MinecraftClient client, int screenWidth, ClientConfig cfg) {
        int size = 92;
        int x = screenWidth - size - 8;
        int y = 8;
        ctx.fill(x, y, x + size, y + size, cfg.panelColor);
        ctx.fill(x, y, x + size, y + 2, cfg.accentColor);
        ctx.fill(x + size / 2, y + 4, x + size / 2 + 1, y + size - 4, 0x443A4B5F);
        ctx.fill(x + 4, y + size / 2, x + size - 4, y + size / 2 + 1, 0x443A4B5F);

        int centerX = x + size / 2;
        int centerY = y + size / 2;
        ctx.fill(centerX - 1, centerY - 1, centerX + 2, centerY + 2, 0xFFFFFFFF);

        double range = Math.max(8, cfg.radarRange);
        double scale = (size / 2.0 - 6) / range;
        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (player == client.player || player.isRemoved()) continue;
            double dx = player.getX() - client.player.getX();
            double dz = player.getZ() - client.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range) continue;
            int px = centerX + (int) Math.round(dx * scale);
            int py = centerY + (int) Math.round(dz * scale);
            ctx.fill(px - 2, py - 2, px + 3, py + 3, cfg.accentColor);
        }
        ctx.drawTextWithShadow(client.textRenderer, "RADAR " + cfg.radarRange + "m", x + 5, y + 5, 0xFFFFFFFF);
    }

    private void drawSameChunk(DrawContext ctx, MinecraftClient client, int screenWidth, ClientConfig cfg) {
        List<AbstractClientPlayerEntity> same = new ArrayList<>();
        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (player != client.player && player.getChunkPos().equals(client.player.getChunkPos())) same.add(player);
        }
        if (same.isEmpty()) return;
        int x = screenWidth - 178;
        int y = 106;
        int h = 16 + Math.min(7, same.size()) * 11;
        ctx.fill(x, y, screenWidth - 8, y + h, cfg.panelColor);
        ctx.drawTextWithShadow(client.textRenderer, "Same chunk / Near", x + 5, y + 4, cfg.accentColor);
        int row = 0;
        for (AbstractClientPlayerEntity player : same) {
            if (row >= 7) break;
            double dist = client.player.distanceTo(player);
            String dir = direction(player.getYaw());
            String line = player.getName().getString() + " §7" + String.format("%.1fm %s", dist, dir);
            ctx.drawTextWithShadow(client.textRenderer, line, x + 5, y + 15 + row * 11, 0xFFFFFFFF);
            row++;
        }
    }

    private void drawCooldowns(DrawContext ctx, MinecraftClient client, int width, int height, ClientConfig cfg) {
        List<String> lines = new ArrayList<>();
        ItemStack main = client.player.getMainHandStack();
        ItemStack off = client.player.getOffHandStack();
        if (!main.isEmpty() && client.player.getItemCooldownManager().isCoolingDown(main)) {
            int percent = (int) Math.ceil(client.player.getItemCooldownManager().getCooldownProgress(main, 0.0f) * 100.0f);
            lines.add(main.getName().getString() + " " + percent + "%");
        }
        if (!off.isEmpty() && client.player.getItemCooldownManager().isCoolingDown(off)) {
            int percent = (int) Math.ceil(client.player.getItemCooldownManager().getCooldownProgress(off, 0.0f) * 100.0f);
            lines.add(off.getName().getString() + " " + percent + "%");
        }
        if (lines.isEmpty()) return;

        int boxW = 126;
        int x = width - boxW - 8;
        int y = height - 18 - lines.size() * 11;
        ctx.fill(x, y, width - 8, height - 8, cfg.panelColor);
        ctx.drawTextWithShadow(client.textRenderer, "Cooldowns", x + 5, y + 4, cfg.accentColor);
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawTextWithShadow(client.textRenderer, lines.get(i), x + 5, y + 15 + i * 11, 0xFFFFFFFF);
        }
    }

    private void drawAimFov(DrawContext ctx, int width, int height, ClientConfig cfg) {
        int cx = width / 2;
        int cy = height / 2;
        int radius = MathHelper.clamp((int) Math.round(cfg.aimFovDegrees * 3.0), 18, Math.min(width, height) / 3);
        int points = 72;
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            int x = cx + (int) Math.round(Math.cos(angle) * radius);
            int y = cy + (int) Math.round(Math.sin(angle) * radius);
            ctx.fill(x, y, x + 1, y + 1, cfg.accentColor);
        }
    }

    private String direction(float yaw) {
        float normalized = MathHelper.wrapDegrees(yaw);
        if (normalized >= -22.5f && normalized < 22.5f) return "S";
        if (normalized >= 22.5f && normalized < 67.5f) return "SW";
        if (normalized >= 67.5f && normalized < 112.5f) return "W";
        if (normalized >= 112.5f || normalized < -157.5f) return "N";
        if (normalized >= -157.5f && normalized < -112.5f) return "NE";
        if (normalized >= -112.5f && normalized < -67.5f) return "E";
        if (normalized >= -67.5f && normalized < -22.5f) return "SE";
        return "?";
    }
}
