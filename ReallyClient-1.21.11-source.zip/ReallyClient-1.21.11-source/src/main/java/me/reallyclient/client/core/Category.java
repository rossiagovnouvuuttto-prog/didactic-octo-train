package me.reallyclient.client.core;

public enum Category {
    COMBAT("PvP"),
    VISUAL("Visuals"),
    HUD("HUD"),
    UTILITY("Utility"),
    SERVER("ReallyWorld"),
    COSMETIC("Cosmetics");

    private final String title;

    Category(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }
}
