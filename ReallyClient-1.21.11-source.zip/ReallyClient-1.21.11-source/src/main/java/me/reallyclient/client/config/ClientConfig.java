package me.reallyclient.client.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ClientConfig {
    public Map<String, Boolean> moduleStates = new HashMap<>();

    public int accentColor = 0xFF4AC7FF;
    public int panelColor = 0xD9141822;
    public int skyColor = 0xFF1E6BFF;

    public float zoomFov = 25.0f;
    public double aimRange = 5.0;
    public double aimFovDegrees = 18.0;
    public double aimSmooth = 0.20;

    public int radarRange = 64;
    public int nearRange = 48;
    public int armorWarningPercent = 18;
    public int abilityRadius = 8;

    public long fixedTimeOfDay = 6000L;

    public int autoCommandIntervalSeconds = 45;
    public int autoSellIntervalSeconds = 60;
    public List<String> autoCommands = new ArrayList<>(List.of("/fix all"));
    public String autoSellCommand = "/sell";

    // Fill this from the actual ReallyWorld rules for the mode you play.
    public List<String> bannedWords = new ArrayList<>();
    public List<String> afkBotNameFragments = new ArrayList<>(List.of("afk-bot", "afk_bot", "afkbot"));

    // Discord Developer Portal application/client ID. 0 = RPC disabled until configured.
    public long discordApplicationId = 0L;
    public String discordDetails = "Playing ReallyWorld";
    public String discordState = "ReallyClient 1.21.11";

    public int blockScanRadius = 12;
    public int blockScanVertical = 8;
    public int blockScanBudgetPerTick = 600;

    public boolean replaceMainMenu = true;
}
